import readline
import rlcompleter
readline.parse_and_bind('tab: complete')
